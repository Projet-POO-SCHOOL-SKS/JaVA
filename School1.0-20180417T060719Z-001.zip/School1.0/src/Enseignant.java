import java.util.Date;


public class Enseignant extends Individus{

	public Enseignant(int idIndividu, String nom, String prenom, String datNais,
			String lieuNais, String adresse, String mail, int tel) {
		super(idIndividu, nom, prenom, datNais, lieuNais, adresse, mail, tel);
		// TODO Auto-generated constructor stub
	}
	

}
