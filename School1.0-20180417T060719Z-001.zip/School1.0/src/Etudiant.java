import java.util.Date;


public class Etudiant extends Individus {
	 
	private String niveauEtud;

	
	
	public Etudiant(){
		
	}

	public Etudiant(int idIndividu, String nom, String prenom, String datNais,
			String lieuNais, String adresse, String mail, int tel,String niveauEtud) {
		super(idIndividu, nom, prenom, datNais, lieuNais, adresse, mail, tel);
		this.niveauEtud = niveauEtud;
		
	}

	public String getNiveauEtud() {
		return niveauEtud;
	}

	public void setNiveauEtud(String niveauEtud) {
		this.niveauEtud = niveauEtud;
	}
	
	
	


}
