
public class Groupe extends Metier {
	
	private int idgroupe;
	private String nomgroupe;
	private final int nbreMax = 20;
	private int idsalle;
	private int idenseigant;
	private int idsession;
	protected Salle salle;
	protected Enseignant enseignat;
	protected Session session;
	
	
	public Groupe() {
		
	}


	public Groupe( String nomgroupe, int idsalle, int idenseigant, int idsession) {
		super();
	
		this.nomgroupe = nomgroupe;
		this.idsalle = idsalle;
		this.idenseigant = idenseigant;
		this.idsession = idsession;

	}


	public int getIdgroupe() {
		return idgroupe;
	}


	public void setIdgroupe(int idgroupe) {
		this.idgroupe = idgroupe;
	}

	public int getIdsalle() {
		return idsalle;
	}


	public void setIdsalle(int idsalle) {
		this.idsalle = idsalle;
	}


	public int getIdenseigant() {
		return idenseigant;
	}


	public void setIdenseigant(int idenseigant) {
		this.idenseigant = idenseigant;
	}


	public int getIdsession() {
		return idsession;
	}


	public void setIdsession(int idsession) {
		this.idsession = idsession;
	}


	public Salle getSalle() {
		return salle;
	}


	public void setSalle(Salle salle) {
		this.salle = salle;
	}


	public Enseignant getEnseignat() {
		return enseignat;
	}


	public void setEnseignat(Enseignant enseignat) {
		this.enseignat = enseignat;
	}


	public Session getSession() {
		return session;
	}


	public void setSession(Session session) {
		this.session = session;
	}


	public String getNomgroupe() {
		return nomgroupe;
	}


	public void setNomgroupe(String nomgroupe) {
		this.nomgroupe = nomgroupe;
	}


	public int getNbreMax() {
		return nbreMax;
	}
	
	
	
	
	
	
	
	
	
	

}
