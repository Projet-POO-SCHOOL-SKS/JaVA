import java.util.List;

public interface IMetier {

	public void ActionAuthentifier();
	public void Ajouter (Etudiant e);
	public void Ajouter (Inscription i);
	public void Ajouter (Groupe g);
	public List<Inscription> Consulter (int numgroupe);
	public List<Etudiant> Consulter ();
	
}
