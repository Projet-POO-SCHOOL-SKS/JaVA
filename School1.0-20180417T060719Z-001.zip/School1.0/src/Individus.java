import java.util.Date;


public class Individus {

	
	private int idIndividu;
	private String nom;
	private String prenom;
	private String datNais;
	private String lieuNais;
	private String Adresse;
	private String mail;
	private int tel;
	
	
	
	public Individus(int idIndividu, String nom, String prenom, String datNais,
			String lieuNais, String adresse, String mail, int tel) {
		
		this.idIndividu = idIndividu;
		this.nom = nom;
		this.prenom = prenom;
		this.datNais = datNais;
		this.lieuNais = lieuNais;
		Adresse = adresse;
		this.mail = mail;
		this.tel = tel;
	}



	public Individus() {
	
	}



	public int getIdIndividu() {
		return idIndividu;
	}



	public void setIdIndividu(int idIndividu) {
		this.idIndividu = idIndividu;
	}



	public String getNom() {
		return nom;
	}



	public void setNom(String nom) {
		this.nom = nom;
	}



	public String getPrenom() {
		return prenom;
	}



	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}



	public String getDatNais() {
		return datNais;
	}



	public void setDatNais(String datNais) {
		this.datNais = datNais;
	}



	public String getLieuNais() {
		return lieuNais;
	}



	public void setLieuNais(String lieuNais) {
		this.lieuNais = lieuNais;
	}



	public String getAdresse() {
		return Adresse;
	}



	public void setAdresse(String adresse) {
		Adresse = adresse;
	}



	public String getMail() {
		return mail;
	}



	public void setMail(String mail) {
		this.mail = mail;
	}



	public int getTel() {
		return tel;
	}



	public void setTel(int tel) {
		this.tel = tel;
	}
	
	
	



	
	
	
	
	
}
