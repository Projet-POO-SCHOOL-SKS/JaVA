import java.util.Date;


public class Inscription extends Metier {
	
	private int idInscription;
	private int idIndividu;
	private String dateInscription;
	protected Individus individus;
	
	
	public Inscription(int idInscription, int idIndividu, String dateInscription) {
		super();
		this.idInscription = idInscription;
		this.idIndividu = idIndividu;
		this.dateInscription = dateInscription;
	}
	
	
	
	public int getIdInscription() {
		return idInscription;
	}
	public void setIdInscription(int idInscription) {
		this.idInscription = idInscription;
	}
	public int getIdIndividu() {
		return idIndividu;
	}
	public void setIdIndividu(int idIndividu) {
		this.idIndividu = idIndividu;
	}
	public String getDateInscription() {
		return dateInscription;
	}
	public void setDateInscription(String dateInscription) {
		this.dateInscription = dateInscription;
	}

	public Individus getIndividus() {
		return individus;
	}

	public void setIndividus(Individus individus) {
		this.individus = individus;
	}
	
	
	
	
	
	
	
	

}
