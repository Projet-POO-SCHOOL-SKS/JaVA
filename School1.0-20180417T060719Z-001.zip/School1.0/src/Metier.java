import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;




public class Metier implements IMetier {

	@Override
	public void Ajouter(Inscription i) {
		// TODO Auto-generated method stub
		
	}
	


	@Override
	public void Ajouter(Etudiant e) {
			Connection conn = MyConnection.Connexion();
			try {
				PreparedStatement ps = conn.prepareStatement("Insert into etudiant(nom_etudiant ,prenom_etudiant,date_naissance,lieu_naissance,adresse ,mail ,niveauEtude) Values (?,?,?,?,?,?,?,?)");
				ps.setString(1, e.getNom());
				ps.setString(2, e.getPrenom());
				ps.setString(3, e.getDatNais());
				ps.setString(4,e.getLieuNais());
				ps.setString(5,e.getAdresse());
				ps.setInt(6, e.getTel());
				ps.setString(7, e.getMail());
				ps.setString(8, e.getNiveauEtud());

				
				ps.executeUpdate();
				ps.close();
				
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		
		}
		
	

	@Override
	public List<Inscription> Consulter(int matricule) {
		try {
			Connection conn = MyConnection.Connexion();
			String sql = "select * from produit";
			PreparedStatement Ps = conn.prepareStatement(sql);
			ResultSet Rs= Ps.executeQuery();
			//table.setModel(DbUtils.resultSetToTableModel(Rs));
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		return null;
	}


	@Override
	public void Ajouter(Groupe g) {
		Connection conn = MyConnection.Connexion();
		try {
			PreparedStatement ps = conn.prepareStatement("Insert into groupe (nom_groupese) Values (?)");
			ps.setString(1, g.getNomgroupe());
			ps.executeUpdate();
			ps.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
	}
		
		
		


	@Override
	public List<Etudiant> Consulter() {
		List<Etudiant> etud  = new ArrayList<Etudiant>();
		Connection conn = MyConnection.Connexion();
		try {
			PreparedStatement ps = conn.prepareStatement("Select * from etudiant ");
			ResultSet rs = ps.executeQuery();
			while (rs.next()){
				Etudiant e = new Etudiant();
				e.setIdIndividu(rs.getInt("id_etudiant"));
				e.setNom(rs.getString("nom_etudiant"));
				e.setPrenom(rs.getString("prenom_etudiant"));
				e.setAdresse(rs.getString("adresse"));
				etud.add(e);
				//ps.close();
			
					
				}
				
		} catch (SQLException e) {
			//e.printStackTrace();
			
		}
		
		return etud;
	}


	




	@Override
	public void ActionAuthentifier() {
		Connection conn = MyConnection.Connexion();

		String profil=null ;
		String username=null ;
		String password=null ;
		String sql = "select nom_utilisateur , mot_passe from utilisateur ";
		
		switch (profil)
		{
		  case "Etudiant":
				try {
					PreparedStatement Ps = conn.prepareStatement(sql);
					ResultSet Rs = Ps.executeQuery();
					int i=0;
					
					if (username.equals("")|| password.equals("")){
						JOptionPane.showMessageDialog(null, " Remplir les champs vide");
					}else{
						while (Rs.next()){
							String username1 = Rs.getString("nom_utilisateur");
							String password1 = Rs.getString("mot_passe");
							if (username1.equals(username)&& password1.equals(password)){
								
								VueInscription a = new VueInscription();
								a.setVisible(true);
								//this.hide();
								//fermer();
								i=1;

								 
							}
						}
						if (i==0){
							JOptionPane.showMessageDialog(null, "login ou mot de passe incorrecte");
						}
					}
				

				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
		
		    break;
		 
		  case "Enseignant":

				try {
					PreparedStatement Ps = conn.prepareStatement(sql);
					ResultSet Rs = Ps.executeQuery();
					int i=0;
					
					if (username.equals("")|| password.equals("")){
						JOptionPane.showMessageDialog(null, " Remplir les champs vide");
					}else{
						while (Rs.next()){
							String username1 = Rs.getString("nom_utilisateur");
							String password1 = Rs.getString("mot_passe");
							if (username1.equals(username)&& password1.equals(password)){
								
								VueInscription a = new VueInscription();
								a.setVisible(true);
								//this.hide();
								//fermer();
								i=1;

								 
							}
						}
						if (i==0){
							JOptionPane.showMessageDialog(null, "login ou mot de passe incorrecte");
						}
					}
				

				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			  
			  
		    break;
		  case "Administrateur":

				try {
					PreparedStatement Ps = conn.prepareStatement(sql);
					ResultSet Rs = Ps.executeQuery();
					int i=0;
					
					if (username.equals("")|| password.equals("")){
						JOptionPane.showMessageDialog(null, " Remplir les champs vide");
					}else{
						while (Rs.next()){
							String username1 = Rs.getString("nom_utilisateur");
							String password1 = Rs.getString("mot_passe");
							if (username1.equals(username)&& password1.equals(password)){
								
								VueInscription a = new VueInscription();
								a.setVisible(true);
								//this.hide();
								//fermer();
								i=1;

								 
							}
						}
						if (i==0){
							JOptionPane.showMessageDialog(null, "login ou mot de passe incorrecte");
						}
					}
				

				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
		    break;
		    
		  case "Secretaire":

				try {
					PreparedStatement Ps = conn.prepareStatement(sql);
					ResultSet Rs = Ps.executeQuery();
					int i=0;
					
					if (username.equals("")|| password.equals("")){
						JOptionPane.showMessageDialog(null, " Remplir les champs vide");
					}else{
						while (Rs.next()){
							String username1 = Rs.getString("nom_utilisateur");
							String password1 = Rs.getString("mot_passe");
							if (username1.equals(username)&& password1.equals(password)){
								
								VueInscription a = new VueInscription();
								a.setVisible(true);
								//this.hide();
								//fermer();
								i=1;

								 
							}
						}
						if (i==0){
							JOptionPane.showMessageDialog(null, "login ou mot de passe incorrecte");
						}
					}
				

				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			    break;
			    
			  case "Directeur":

					try {
						PreparedStatement Ps = conn.prepareStatement(sql);
						ResultSet Rs = Ps.executeQuery();
						int i=0;
						
						if (username.equals("")|| password.equals("")){
							JOptionPane.showMessageDialog(null, " Remplir les champs vide");
						}else{
							while (Rs.next()){
								String username1 = Rs.getString("nom_utilisateur");
								String password1 = Rs.getString("mot_passe");
								if (username1.equals(username)&& password1.equals(password)){
									
									VueInscription a = new VueInscription();
									a.setVisible(true);
									//this.hide();
									//fermer();
									i=1;

									 
								}
							}
							if (i==0){
								JOptionPane.showMessageDialog(null, "login ou mot de passe incorrecte");
							}
						}
					

					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
			    break;
		  default:
		    System.out.println("Erreur !!!!! ");
		}
		
		
	}

}
