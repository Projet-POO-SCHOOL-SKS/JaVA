

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;

public class MyConnection{
	
	
	 private static Connection conn = null;

	 public static Connection Connexion(){
		
	 try{
		 Class.forName("com.mysql.jdbc.Driver")	; 
		 conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/school1.0","root","root") ;
		 System.out.println("Connection reussi");
	 	}catch (ClassNotFoundException e){
		System.out.println("Erreur Driver ");	
	 	} catch (SQLException e ){
		System.out.println("Erreur DataBase ");
	 	}
	return conn;
		
	 	
	 }
	 
	 public static void main(String[] args) {
		System.out.println(MyConnection.Connexion());
	}



}
