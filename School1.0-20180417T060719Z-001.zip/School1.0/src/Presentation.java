import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Presentation {
public static void main(String[] args) throws ParseException {

	Metier p =new Metier();
	//Etudiant e = new Etudiant(1, "sam", "samia",23/12/20010," tizi", "paris", "sam@gmail.com", 0605665650, "bac");
	//p.Ajouter(e);
	System.out.println("ok");
	
	
	/* date systeme
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
	String dateStr = simpleDateFormat.format(new Date());
	System.out.println(dateStr);
	*/
	
	
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
	
	Date date = simpleDateFormat.parse("25/12/2010");
	
	System.out.println(date);
	
	
}
}
