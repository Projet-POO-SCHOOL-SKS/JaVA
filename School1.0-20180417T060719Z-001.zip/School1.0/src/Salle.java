
public class Salle {

}
