
public class Utilisateur {
	int iduser ;
	String login;
	String password;

	
	public Utilisateur(int iduser, String login, String password) {

		this.iduser = iduser;
		this.login = login;
		this.password = password;
	}

	public Utilisateur() {

	}
	
	

	public int getIduser() {
		return iduser;
	}


	public void setIduser(int iduser) {
		this.iduser = iduser;
	}


	public String getLogin() {
		return login;
	}


	public void setLogin(String login) {
		this.login = login;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	
	

}

