import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.SystemColor;

import javax.swing.UIManager;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JSeparator;


public class VueAcceuil extends JFrame {

	private JPanel contentPane;
	
	
	
	void fermer(){
		dispose();
	}
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VueAcceuil frame = new VueAcceuil();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VueAcceuil() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 768);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(173, 216, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.inactiveCaption);
		panel.setForeground(UIManager.getColor("CheckBoxMenuItem.selectionBackground"));
		panel.setBounds(60, 184, 893, 267);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblProfil = new JLabel("Selectionnez Votre Profil");
		lblProfil.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblProfil.setBounds(85, 53, 243, 28);
		panel.add(lblProfil);
		
		JButton btnEtudiant = new JButton("Etudiant ");
		btnEtudiant.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VueAuthentification v = new VueAuthentification();
				v.setVisible(true);
				
				
			}
		});
		btnEtudiant.setBounds(60, 127, 131, 97);
		panel.add(btnEtudiant);
		
		JButton btnEnseignat = new JButton("Enseignant ");
		btnEnseignat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VueAuthentification v = new VueAuthentification();
				v.setVisible(true);
			}
		});
		btnEnseignat.setBounds(212, 127, 131, 97);
		panel.add(btnEnseignat);
		
		JButton btnAdministarteur = new JButton("Administarteur");
		btnAdministarteur.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VueAuthentification v = new VueAuthentification();
				v.setVisible(true);
			}
		});
		btnAdministarteur.setBounds(371, 127, 146, 97);
		panel.add(btnAdministarteur);
		
		JButton btnSecretaire = new JButton("Secretaire");
		btnSecretaire.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VueAuthentification v = new VueAuthentification();
				v.setVisible(true);
				fermer();
			}
		});
		btnSecretaire.setBounds(538, 127, 146, 97);
		panel.add(btnSecretaire);
		
		JButton btnDirecteur = new JButton("Directeur");
		btnDirecteur.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VueAuthentificationProfil v = new VueAuthentificationProfil();
				v.setVisible(true);
			}
		});
		btnDirecteur.setBounds(702, 127, 146, 97);
		panel.add(btnDirecteur);
		
		JButton btnQuitter = new JButton("Quitter");
		btnQuitter.setBounds(716, 11, 89, 23);
		panel.add(btnQuitter);
		btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(-1);
			}
		});
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 163, 1018, 2);
		contentPane.add(separator);
		
		JLabel lblSchool = new JLabel("School1.0");
		lblSchool.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblSchool.setBounds(701, 94, 192, 58);
		contentPane.add(lblSchool);
	}
}
