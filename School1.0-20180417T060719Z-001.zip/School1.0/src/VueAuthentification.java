

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;





import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;

import java.awt.Font;

import javax.swing.JSeparator;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class VueAuthentification extends JFrame {

	private JPanel contentPane;
	private JTextField textField_login;
	private JPasswordField passwordField;
	
	Connection conn = MyConnection.Connexion();
	PreparedStatement Ps = null;
	ResultSet Rs = null;
	

	
	void fermer(){
		dispose();
	}
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VueAuthentification frame = new VueAuthentification();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VueAuthentification() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblLogin = new JLabel("Login  :");
		lblLogin.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblLogin.setBounds(313, 275, 109, 33);
		contentPane.add(lblLogin);
		
		textField_login = new JTextField();
		textField_login.setBounds(424, 279, 192, 28);
		contentPane.add(textField_login);
		textField_login.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPassword.setBounds(313, 319, 79, 14);
		contentPane.add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(424, 314, 192, 28);
		contentPane.add(passwordField);
		
		JButton btnOk = new JButton("S'authentifier");
		btnOk.setBounds(260, 432, 162, 50);
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	
				/********************************************************************************/
				String username = textField_login.getText().toString();
				String password = passwordField.getText().toString(); 
				
				String sql = "select nom_utilisateur , mot_passe from utilisateur ";
				try {
					Ps = conn.prepareStatement(sql);
					Rs = Ps.executeQuery();
					int i=0;
					
					if (username.equals("")|| password.equals("")){
						JOptionPane.showMessageDialog(null, " Remplir les champs vide");
					}else{
						while (Rs.next()){
							String username1 = Rs.getString("nom_utilisateur");
							String password1 = Rs.getString("mot_passe");
							if (username1.equals(username)&& password1.equals(password)){
								
								VueInscription a = new VueInscription();
								a.setVisible(true);
								this.hide();
								fermer();
								i=1;

								 
							}
						}
						if (i==0){
							JOptionPane.showMessageDialog(null, "login ou mot de passe incorrecte");
						}
					}
				

				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			}

			private void hide() {	
				fermer();
			
				/********************************************************************************/	
				
				
			}
		});
		contentPane.add(btnOk);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setBounds(445, 432, 143, 50);
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField_login.setText(null);	
				passwordField.setText(null);
			}
		});
		contentPane.add(btnReset);
		
		JButton btnQuit = new JButton("Quit");
		btnQuit.setBounds(625, 432, 123, 50);
		btnQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
		});
		contentPane.add(btnQuit);
		
		JLabel labelImage = new JLabel("");
		labelImage.setBounds(248, 56, 388, 84);
		labelImage.setIcon(new ImageIcon("C:\\Users\\Samia CHOUBANE\\Pictures\\Icon\\dalerte-des-infos-des-hommes-utilisateur-icone-7789-64.png"));
		contentPane.add(labelImage);
		
		JLabel lblAuthentification = new JLabel("Veuillez vous Authentification");
		lblAuthentification.setBounds(317, 83, 270, 34);
		lblAuthentification.setFont(new Font("Trebuchet MS", Font.BOLD, 16));
		contentPane.add(lblAuthentification);
		
		JSeparator separatorhaut = new JSeparator();
		separatorhaut.setBounds(0, 196, 1008, 2);
		contentPane.add(separatorhaut);
		
		JSeparator separatorbas = new JSeparator();
		separatorbas.setBounds(0, 535, 1008, 2);
		contentPane.add(separatorbas);
		
		JButton btnNewButton = new JButton("Retour");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VueAcceuil v = new VueAcceuil();
				v.setVisible(true);
			}
		});
		btnNewButton.setBounds(881, 171, 89, 23);
		contentPane.add(btnNewButton);
	}
}
