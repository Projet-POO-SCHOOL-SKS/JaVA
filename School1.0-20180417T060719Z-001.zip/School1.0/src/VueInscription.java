import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import javax.swing.JComboBox;




public class VueInscription extends JFrame {

	private JPanel contentPane;
	private JTextField textField_nom;
	private JTextField textField_prenom;
	private JTextField textField_adresse;
	private JTextField textField_mail;
	private JTextField textField_tel;
	private JTextField textField_dateNaissance;
	private JTextField textField_LieuNaissance;
	private JTextField textField_niveauEtud;
	private JTextField textField_IdEtudiant;
	
	
	Connection conn =null;
	PreparedStatement Ps= null;
	ResultSet Rs = null;
	
	
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VueInscription frame = new VueInscription();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VueInscription() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JSeparator separator_haut = new JSeparator();
		separator_haut.setBounds(0, 130, 998, 2);
		contentPane.add(separator_haut);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 634, 998, 2);
		contentPane.add(separator);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(0, 143, 1008, 493);
		contentPane.add(tabbedPane);
		
		JPanel panel_inscription = new JPanel();
		tabbedPane.addTab("Gestion Inscription ", null, panel_inscription, null);
		panel_inscription.setLayout(null);
		
		JPanel panel_ajouerEtudiant = new JPanel();
		panel_ajouerEtudiant.setBounds(49, 11, 413, 451);
		panel_inscription.add(panel_ajouerEtudiant);
		panel_ajouerEtudiant.setLayout(null);
		
		JLabel lblAjouterUnEtudiant = new JLabel("      Ajouter un etudiant ");
		lblAjouterUnEtudiant.setBounds(138, 11, 168, 14);
		panel_ajouerEtudiant.add(lblAjouterUnEtudiant);
		
		textField_nom = new JTextField();
		textField_nom.setBounds(204, 80, 168, 20);
		panel_ajouerEtudiant.add(textField_nom);
		textField_nom.setColumns(10);
		
		textField_prenom = new JTextField();
		textField_prenom.setColumns(10);
		textField_prenom.setBounds(204, 111, 168, 20);
		panel_ajouerEtudiant.add(textField_prenom);
		
		textField_adresse = new JTextField();
		textField_adresse.setColumns(10);
		textField_adresse.setBounds(204, 142, 168, 20);
		panel_ajouerEtudiant.add(textField_adresse);
		
		textField_mail = new JTextField();
		textField_mail.setColumns(10);
		textField_mail.setBounds(204, 173, 168, 20);
		panel_ajouerEtudiant.add(textField_mail);
		
		textField_tel = new JTextField();
		textField_tel.setColumns(10);
		textField_tel.setBounds(204, 213, 168, 20);
		panel_ajouerEtudiant.add(textField_tel);
		
		textField_dateNaissance = new JTextField();
		textField_dateNaissance.setColumns(10);
		textField_dateNaissance.setBounds(204, 249, 168, 20);
		panel_ajouerEtudiant.add(textField_dateNaissance);
		
		textField_LieuNaissance = new JTextField();
		textField_LieuNaissance.setColumns(10);
		textField_LieuNaissance.setBounds(204, 284, 168, 20);
		panel_ajouerEtudiant.add(textField_LieuNaissance);
		
		textField_niveauEtud = new JTextField();
		textField_niveauEtud.setColumns(10);
		textField_niveauEtud.setBounds(204, 326, 168, 20);
		panel_ajouerEtudiant.add(textField_niveauEtud);
		
		JLabel lblNom = new JLabel("Nom : ");
		lblNom.setBounds(75, 83, 105, 14);
		panel_ajouerEtudiant.add(lblNom);
		
		JLabel lblPrnom = new JLabel("Pr\u00E9nom : ");
		lblPrnom.setBounds(75, 108, 105, 14);
		panel_ajouerEtudiant.add(lblPrnom);
		
		JLabel lblAdresse = new JLabel("Adresse :");
		lblAdresse.setBounds(75, 145, 105, 14);
		panel_ajouerEtudiant.add(lblAdresse);
		
		JLabel lblMail = new JLabel("mail : ");
		lblMail.setBounds(75, 179, 105, 14);
		panel_ajouerEtudiant.add(lblMail);
		
		JLabel lblTelephone = new JLabel("Telephone : ");
		lblTelephone.setBounds(75, 216, 105, 14);
		panel_ajouerEtudiant.add(lblTelephone);
		
		JLabel lblDateNaissance = new JLabel("Date Naissance : ");
		lblDateNaissance.setBounds(75, 252, 105, 14);
		panel_ajouerEtudiant.add(lblDateNaissance);
		
		JLabel lblLieuNaissance = new JLabel("Lieu Naissance: ");
		lblLieuNaissance.setBounds(75, 287, 105, 14);
		panel_ajouerEtudiant.add(lblLieuNaissance);
		
		JLabel lblNiveauEtude = new JLabel("Niveau Etude : ");
		lblNiveauEtude.setBounds(75, 329, 105, 14);
		panel_ajouerEtudiant.add(lblNiveauEtude);
		
		JButton btnAjouter = new JButton("Ajouter ");
		btnAjouter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection conn = MyConnection.Connexion();
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
				
				try {
					PreparedStatement ps = conn.prepareStatement("Insert into etudiant (nom_etudiant,prenom_etudiant,date_naissance,lieu_naissance,adresse,tel ,mail ,niveauEtude) Values (?,?,?,?,?,?,?,?)");
					ps.setString(1, textField_nom.getText());
					ps.setString(2, textField_prenom.getText());
					ps.setString(3,textField_dateNaissance.getText());
					ps.setString(4,textField_LieuNaissance.getText());
					ps.setString(5,textField_adresse.getText());
					ps.setString(6, textField_tel.getText());
					ps.setString(7,textField_mail.getText());
					ps.setString(8,textField_niveauEtud.getText());

					
					textField_nom.setText(null);	
					textField_prenom.setText(null);
					textField_dateNaissance.setText(null);
					textField_LieuNaissance.setText(null);
					textField_mail.setText(null);
					textField_niveauEtud.setText(null);
					textField_tel.setText(null);
					textField_adresse.setText(null);
					JOptionPane.showMessageDialog(null, "Etudiant Ajout� !!");
					
					
					
					
					ps.executeUpdate();
					ps.close();
					
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				
			}
		});
		btnAjouter.setBounds(106, 392, 89, 23);
		panel_ajouerEtudiant.add(btnAjouter);
		
		JButton btnEffacer = new JButton("Effacer");
		btnEffacer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_nom.setText(null);	
				textField_prenom.setText(null);
				textField_dateNaissance.setText(null);
				textField_LieuNaissance.setText(null);
				textField_mail.setText(null);
				textField_niveauEtud.setText(null);
				textField_tel.setText(null);
				textField_adresse.setText(null);
				
				
				
			}
		});
		btnEffacer.setBounds(239, 392, 89, 23);
		panel_ajouerEtudiant.add(btnEffacer);
		
		JPanel panel_ajouterInscription = new JPanel();
		panel_ajouterInscription.setLayout(null);
		panel_ajouterInscription.setBounds(547, 11, 413, 451);
		panel_inscription.add(panel_ajouterInscription);
		
		JLabel lblAjouterUneInscription = new JLabel("      Ajouter une inscription ");
		lblAjouterUneInscription.setBounds(138, 11, 168, 14);
		panel_ajouterInscription.add(lblAjouterUneInscription);
		
		textField_IdEtudiant = new JTextField();
		textField_IdEtudiant.setBounds(186, 113, 166, 20);
		panel_ajouterInscription.add(textField_IdEtudiant);
		textField_IdEtudiant.setColumns(10);
		
		JLabel lblNumeroEtudiant = new JLabel("Numero Etudiant :\r\n");
		lblNumeroEtudiant.setBounds(73, 113, 119, 20);
		panel_ajouterInscription.add(lblNumeroEtudiant);
		
		JLabel lblFormation = new JLabel("Formation : ");
		lblFormation.setBounds(73, 144, 119, 20);
		panel_ajouterInscription.add(lblFormation);
		
		JLabel lblGroupe = new JLabel("Groupe :");
		lblGroupe.setBounds(73, 175, 119, 20);
		panel_ajouterInscription.add(lblGroupe);
		
		JComboBox comboBox_formation = new JComboBox();
		comboBox_formation.setBounds(186, 144, 168, 20);
		panel_ajouterInscription.add(comboBox_formation);
		
		JComboBox comboBox_groupe = new JComboBox();
		comboBox_groupe.setBounds(184, 175, 168, 20);
		panel_ajouterInscription.add(comboBox_groupe);
		
		JButton btnAjouter_1 = new JButton("Ajouter");
		btnAjouter_1.setBounds(117, 270, 89, 23);
		panel_ajouterInscription.add(btnAjouter_1);
		
		JButton btnEffacer_1 = new JButton("Effacer");
		btnEffacer_1.setBounds(228, 270, 89, 23);
		panel_ajouterInscription.add(btnEffacer_1);
		
		JPanel panel_paiement = new JPanel();
		tabbedPane.addTab("Gestion Paiement", null, panel_paiement, null);
		
		JPanel panel_contrat = new JPanel();
		tabbedPane.addTab("Gestion Contrat", null, panel_contrat, null);
		
		JPanel panel_MotPasse = new JPanel();
		tabbedPane.addTab("Modification Mot Passe", null, panel_MotPasse, null);
		
		JButton btnQuitter = new JButton("Quitter");
		btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(-1);
			}
		});
		btnQuitter.setBounds(891, 96, 89, 23);
		contentPane.add(btnQuitter);
	}
}
